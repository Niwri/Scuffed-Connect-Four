Alrighty so uh,

RULES:
1) Whoever connects 4 of their colored circles wins. 
2) Right, next.

INSTRUCTIONS:
Player One - 
	Move left and right of columns using A and D respectively. 
	Press spacebar to select your choice
	Oh yeah, and, the piece will be placed at the bottommost unfilled circle of the column
Player Two -
	Move left and right of columns using Left Arrow Key and Right Arrow Key respectively
	Press enter/return to select your choice
	Oh yeah, and--

HOW TO EXIT:
	Alt+F4, or just close the window

FEATURES:
	Connect Four baby...
	Multiplayer...
	Scores...
	Fun.
	
	
